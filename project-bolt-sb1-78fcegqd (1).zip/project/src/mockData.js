export const users = [
  {
    id: 1,
    name: "John Doe",
    email: "john.doe@example.com",
    phone: "+27 82 123 4567",
    status: "Active",
    lastSeen: "2025-01-02 14:30",
    joinDate: "2024-03-15",
    totalTrips: 45
  },
  {
    id: 2,
    name: "Sarah Johnson",
    email: "sarah.j@example.com",
    phone: "+27 83 987 6543",
    status: "Active",
    lastSeen: "2025-01-02 09:15",
    joinDate: "2024-05-20",
    totalTrips: 23
  },
  {
    id: 3,
    name: "Mike Wilson",
    email: "mike.wilson@example.com",
    phone: "+27 84 555 1234",
    status: "Suspended",
    lastSeen: "2024-12-28 16:45",
    joinDate: "2024-01-10",
    totalTrips: 67
  },
  {
    id: 4,
    name: "Lisa Chen",
    email: "lisa.chen@example.com",
    phone: "+27 85 777 8888",
    status: "Active",
    lastSeen: "2025-01-02 11:20",
    joinDate: "2024-07-03",
    totalTrips: 12
  },
  {
    id: 5,
    name: "David Brown",
    email: "david.brown@example.com",
    phone: "+27 86 444 5555",
    status: "Active",
    lastSeen: "2025-01-01 20:30",
    joinDate: "2024-02-14",
    totalTrips: 89
  }
];

export const tickets = [
  {
    id: "TK-001",
    subject: "App crashes when selecting route",
    status: "OPEN",
    priority: "High",
    assignedTo: "Tech Support",
    createdBy: "john.doe@example.com",
    createdAt: "2025-01-02 10:30",
    description: "The app crashes consistently when I try to select a route from Johannesburg to Pretoria. This happens every time I open the route selection screen."
  },
  {
    id: "TK-002",
    subject: "Incorrect taxi fare calculation",
    status: "RESOLVED",
    priority: "Medium",
    assignedTo: "Sarah Mitchell",
    createdBy: "sarah.j@example.com",
    createdAt: "2025-01-01 14:15",
    description: "The fare shown in the app doesn't match what the taxi driver is charging. There seems to be a discrepancy in the pricing algorithm."
  },
  {
    id: "TK-003",
    subject: "Cannot update profile information",
    status: "OPEN",
    priority: "Low",
    assignedTo: "John Smith",
    createdBy: "mike.wilson@example.com",
    createdAt: "2024-12-30 09:45",
    description: "When I try to update my phone number in the profile section, the changes don't save and I get an error message."
  },
  {
    id: "TK-004",
    subject: "GPS location not accurate",
    status: "CLOSED",
    priority: "High",
    assignedTo: "Tech Support",
    createdBy: "lisa.chen@example.com",
    createdAt: "2024-12-28 16:20",
    description: "The app shows my location as being 2km away from where I actually am. This makes it difficult to find nearby taxi ranks."
  },
  {
    id: "TK-005",
    subject: "Push notifications not working",
    status: "OPEN",
    priority: "Medium",
    assignedTo: "David Lee",
    createdBy: "david.brown@example.com",
    createdAt: "2025-01-02 08:00",
    description: "I'm not receiving any push notifications about route updates or fare changes, even though I have notifications enabled in settings."
  }
];

export const taxiRanks = [
  {
    id: 1,
    name: "Johannesburg Central Taxi Rank",
    location: "Corner of Pritchard & Von Wielligh Street, Johannesburg",
    coordinates: { lat: -26.2041, lng: 28.0473 },
    pricing: "R15 - R45 per trip",
    capacity: 150,
    operatingHours: "05:00 - 22:00",
    facilities: ["Shelter", "Security", "Toilets", "Food Vendors"]
  },
  {
    id: 2,
    name: "Cape Town Station Deck",
    location: "Adderley Street, Cape Town",
    coordinates: { lat: -33.9249, lng: 18.4241 },
    pricing: "R12 - R35 per trip",
    capacity: 200,
    operatingHours: "04:30 - 23:00",
    facilities: ["Shelter", "Security", "ATM", "Shops"]
  },
  {
    id: 3,
    name: "Durban Workshop Taxi Rank",
    location: "Workshop Shopping Centre, Durban",
    coordinates: { lat: -29.8587, lng: 31.0218 },
    pricing: "R10 - R30 per trip",
    capacity: 120,
    operatingHours: "05:30 - 21:30",
    facilities: ["Shelter", "Security", "Toilets"]
  },
  {
    id: 4,
    name: "Pretoria Central Taxi Rank",
    location: "Church Street, Pretoria",
    coordinates: { lat: -25.7479, lng: 28.2293 },
    pricing: "R8 - R25 per trip",
    capacity: 80,
    operatingHours: "05:00 - 22:30",
    facilities: ["Shelter", "Security", "Food Vendors"]
  },
  {
    id: 5,
    name: "Soweto Taxi Rank",
    location: "Vilakazi Street, Orlando West, Soweto",
    coordinates: { lat: -26.2309, lng: 27.9056 },
    pricing: "R5 - R20 per trip",
    capacity: 100,
    operatingHours: "05:00 - 21:00",
    facilities: ["Shelter", "Security"]
  }
];

export const routes = [
  {
    id: 1,
    name: "JHB to PTA Express",
    origin: "Johannesburg Central",
    destination: "Pretoria Central",
    distance: "58 km",
    pricingModel: "Fixed Rate",
    basePrice: 45,
    estimatedTime: "1h 15min",
    popularity: "High"
  },
  {
    id: 2,
    name: "Cape Town City Circle",
    origin: "Cape Town Station",
    destination: "Bellville",
    distance: "25 km",
    pricingModel: "Distance Based",
    basePrice: 25,
    estimatedTime: "45min",
    popularity: "Medium"
  },
  {
    id: 3,
    name: "Durban Coastal Route",
    origin: "Durban Workshop",
    destination: "Pinetown",
    distance: "18 km",
    pricingModel: "Fixed Rate",
    basePrice: 18,
    estimatedTime: "35min",
    popularity: "High"
  },
  {
    id: 4,
    name: "Soweto Local",
    origin: "Soweto Taxi Rank",
    destination: "Johannesburg CBD",
    distance: "15 km",
    pricingModel: "Distance Based",
    basePrice: 15,
    estimatedTime: "30min",
    popularity: "Very High"
  },
  {
    id: 5,
    name: "East Rand Express",
    origin: "Germiston",
    destination: "Benoni",
    distance: "22 km",
    pricingModel: "Fixed Rate",
    basePrice: 20,
    estimatedTime: "40min",
    popularity: "Low"
  }
];

export const dashboardStats = {
  totalUsers: 12847,
  activeTaxiRanks: 156,
  openTickets: 23,
  pendingRoutes: 8,
  systemHealth: {
    status: "Healthy",
    uptime: "99.8%",
    lastIncident: "2024-12-15",
    activeServices: 12,
    totalServices: 12
  }
};

export const notificationTemplates = [
  {
    id: 1,
    name: "Route Update",
    title: "Route Information Updated",
    body: "The route from {origin} to {destination} has been updated with new pricing and schedule information.",
    variables: ["origin", "destination"]
  },
  {
    id: 2,
    name: "Fare Change",
    title: "Fare Update Notification",
    body: "Taxi fares for {route} have been updated. New fare: R{amount}",
    variables: ["route", "amount"]
  },
  {
    id: 3,
    name: "Service Disruption",
    title: "Service Alert",
    body: "Service disruption on {route} due to {reason}. Expected resolution: {time}",
    variables: ["route", "reason", "time"]
  },
  {
    id: 4,
    name: "Welcome Message",
    title: "Welcome to GeoOut!",
    body: "Welcome {username}! Start exploring taxi routes and real-time pricing in your area.",
    variables: ["username"]
  }
];