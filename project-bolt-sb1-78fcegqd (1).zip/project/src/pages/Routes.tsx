import React, { useState } from 'react';
import {
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Chip,
  Box,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem
} from '@mui/material';
import { Add } from '@mui/icons-material';
import Layout from '../components/Layout/Layout';
import { routes } from '../mockData';

const Routes: React.FC = () => {
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [newRoute, setNewRoute] = useState({
    name: '',
    origin: '',
    destination: '',
    distance: '',
    pricingModel: 'Fixed Rate',
    basePrice: ''
  });

  const handleAddRoute = () => {
    console.log('Add new route:', newRoute);
    setAddDialogOpen(false);
    setNewRoute({
      name: '',
      origin: '',
      destination: '',
      distance: '',
      pricingModel: 'Fixed Rate',
      basePrice: ''
    });
  };

  const getPopularityColor = (popularity: string) => {
    switch (popularity) {
      case 'Very High': return 'error';
      case 'High': return 'warning';
      case 'Medium': return 'info';
      case 'Low': return 'default';
      default: return 'default';
    }
  };

  return (
    <Layout pageTitle="Routes Management">
      <div className="space-y-4">
        {/* Header with Add Button */}
        <Box className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-semibold text-gray-800">Routes Overview</h2>
            <p className="text-gray-600">Manage taxi routes and pricing models</p>
          </div>
          <Button
            variant="contained"
            startIcon={<Add />}
            onClick={() => setAddDialogOpen(true)}
            className="bg-blue-600 hover:bg-blue-700"
          >
            Add Route
          </Button>
        </Box>

        {/* Routes Table */}
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow className="bg-gray-50">
                <TableCell className="font-semibold">Route Name</TableCell>
                <TableCell className="font-semibold">Origin</TableCell>
                <TableCell className="font-semibold">Destination</TableCell>
                <TableCell className="font-semibold">Distance</TableCell>
                <TableCell className="font-semibold">Pricing Model</TableCell>
                <TableCell className="font-semibold">Base Price</TableCell>
                <TableCell className="font-semibold">Est. Time</TableCell>
                <TableCell className="font-semibold">Popularity</TableCell>
                <TableCell className="font-semibold">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {routes.map((route) => (
                <TableRow key={route.id} hover>
                  <TableCell className="font-medium">{route.name}</TableCell>
                  <TableCell>{route.origin}</TableCell>
                  <TableCell>{route.destination}</TableCell>
                  <TableCell>{route.distance}</TableCell>
                  <TableCell>
                    <Chip
                      label={route.pricingModel}
                      size="small"
                      variant="outlined"
                      color={route.pricingModel === 'Fixed Rate' ? 'primary' : 'secondary'}
                    />
                  </TableCell>
                  <TableCell className="font-medium">R{route.basePrice}</TableCell>
                  <TableCell className="text-gray-600">{route.estimatedTime}</TableCell>
                  <TableCell>
                    <Chip
                      label={route.popularity}
                      size="small"
                      color={getPopularityColor(route.popularity) as any}
                    />
                  </TableCell>
                  <TableCell>
                    <Box className="flex gap-2">
                      <Button
                        size="small"
                        variant="outlined"
                        onClick={() => console.log('Edit route:', route)}
                      >
                        Edit
                      </Button>
                      <Button
                        size="small"
                        variant="contained"
                        onClick={() => console.log('View route:', route)}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        View
                      </Button>
                    </Box>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        {/* Add Route Dialog */}
        <Dialog open={addDialogOpen} onClose={() => setAddDialogOpen(false)} maxWidth="sm" fullWidth>
          <DialogTitle>Add New Route</DialogTitle>
          <DialogContent>
            <div className="space-y-4 pt-2">
              <TextField
                fullWidth
                label="Route Name"
                value={newRoute.name}
                onChange={(e) => setNewRoute({ ...newRoute, name: e.target.value })}
              />
              <TextField
                fullWidth
                label="Origin"
                value={newRoute.origin}
                onChange={(e) => setNewRoute({ ...newRoute, origin: e.target.value })}
              />
              <TextField
                fullWidth
                label="Destination"
                value={newRoute.destination}
                onChange={(e) => setNewRoute({ ...newRoute, destination: e.target.value })}
              />
              <TextField
                fullWidth
                label="Distance"
                placeholder="e.g., 25 km"
                value={newRoute.distance}
                onChange={(e) => setNewRoute({ ...newRoute, distance: e.target.value })}
              />
              <FormControl fullWidth>
                <InputLabel>Pricing Model</InputLabel>
                <Select
                  value={newRoute.pricingModel}
                  label="Pricing Model"
                  onChange={(e) => setNewRoute({ ...newRoute, pricingModel: e.target.value })}
                >
                  <MenuItem value="Fixed Rate">Fixed Rate</MenuItem>
                  <MenuItem value="Distance Based">Distance Based</MenuItem>
                </Select>
              </FormControl>
              <TextField
                fullWidth
                label="Base Price"
                type="number"
                value={newRoute.basePrice}
                onChange={(e) => setNewRoute({ ...newRoute, basePrice: e.target.value })}
                InputProps={{
                  startAdornment: <span className="text-gray-500 mr-1">R</span>
                }}
              />
            </div>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setAddDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleAddRoute} variant="contained" className="bg-blue-600 hover:bg-blue-700">
              Add Route
            </Button>
          </DialogActions>
        </Dialog>
      </div>
    </Layout>
  );
};

export default Routes;