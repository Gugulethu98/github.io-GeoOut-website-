import React, { useState } from 'react';
import {
  Paper,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Typography,
  Box,
  Card,
  CardContent,
  Grid,
  Chip,
  Divider
} from '@mui/material';
import {
  Send,
  Notifications as NotificationsIcon,
  Email,
  Sms,
  Template
} from '@mui/icons-material';
import Layout from '../components/Layout/Layout';
import { notificationTemplates } from '../mockData';

const Notifications: React.FC = () => {
  const [notification, setNotification] = useState({
    title: '',
    body: '',
    target: 'all',
    type: 'push'
  });
  const [selectedTemplate, setSelectedTemplate] = useState('');

  const handleSendNotification = () => {
    const payload = {
      title: notification.title,
      body: notification.body,
      target: notification.target,
      type: notification.type,
      timestamp: new Date().toISOString()
    };
    
    console.log('Sending notification:', payload);
    
    // Reset form
    setNotification({
      title: '',
      body: '',
      target: 'all',
      type: 'push'
    });
    setSelectedTemplate('');
  };

  const handleTemplateSelect = (templateId: string) => {
    const template = notificationTemplates.find(t => t.id.toString() === templateId);
    if (template) {
      setNotification({
        ...notification,
        title: template.title,
        body: template.body
      });
      setSelectedTemplate(templateId);
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'push': return <NotificationsIcon className="text-blue-600" />;
      case 'email': return <Email className="text-green-600" />;
      case 'sms': return <Sms className="text-orange-600" />;
      default: return <NotificationsIcon className="text-gray-600" />;
    }
  };

  return (
    <Layout pageTitle="Notifications">
      <div className="space-y-6">
        <Grid container spacing={4}>
          {/* Send Notification Form */}
          <Grid item xs={12} md={8}>
            <Paper className="p-6">
              <Typography variant="h6" className="font-semibold text-gray-800 mb-4">
                Send Notification
              </Typography>
              
              <div className="space-y-4">
                <FormControl fullWidth>
                  <InputLabel>Notification Template</InputLabel>
                  <Select
                    value={selectedTemplate}
                    label="Notification Template"
                    onChange={(e) => handleTemplateSelect(e.target.value)}
                  >
                    <MenuItem value="">Custom Message</MenuItem>
                    {notificationTemplates.map((template) => (
                      <MenuItem key={template.id} value={template.id.toString()}>
                        {template.name}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>

                <TextField
                  fullWidth
                  label="Notification Title"
                  value={notification.title}
                  onChange={(e) => setNotification({ ...notification, title: e.target.value })}
                  required
                />

                <TextField
                  fullWidth
                  label="Message Body"
                  multiline
                  rows={4}
                  value={notification.body}
                  onChange={(e) => setNotification({ ...notification, body: e.target.value })}
                  required
                />

                <Box className="flex gap-4">
                  <FormControl className="flex-1">
                    <InputLabel>Target Audience</InputLabel>
                    <Select
                      value={notification.target}
                      label="Target Audience"
                      onChange={(e) => setNotification({ ...notification, target: e.target.value })}
                    >
                      <MenuItem value="all">All Users</MenuItem>
                      <MenuItem value="active">Active Users</MenuItem>
                      <MenuItem value="drivers">Drivers Only</MenuItem>
                      <MenuItem value="passengers">Passengers Only</MenuItem>
                    </Select>
                  </FormControl>

                  <FormControl className="flex-1">
                    <InputLabel>Notification Type</InputLabel>
                    <Select
                      value={notification.type}
                      label="Notification Type"
                      onChange={(e) => setNotification({ ...notification, type: e.target.value })}
                    >
                      <MenuItem value="push">Push Notification</MenuItem>
                      <MenuItem value="email">Email</MenuItem>
                      <MenuItem value="sms">SMS</MenuItem>
                    </Select>
                  </FormControl>
                </Box>

                <Button
                  variant="contained"
                  startIcon={<Send />}
                  onClick={handleSendNotification}
                  disabled={!notification.title || !notification.body}
                  className="bg-blue-600 hover:bg-blue-700"
                  size="large"
                >
                  Send Notification
                </Button>
              </div>
            </Paper>
          </Grid>

          {/* Notification Templates */}
          <Grid item xs={12} md={4}>
            <Paper className="p-6">
              <Typography variant="h6" className="font-semibold text-gray-800 mb-4 flex items-center">
                <Template className="mr-2" />
                Notification Templates
              </Typography>
              
              <div className="space-y-3">
                {notificationTemplates.map((template) => (
                  <Card 
                    key={template.id} 
                    className={`cursor-pointer transition-all hover:shadow-md ${
                      selectedTemplate === template.id.toString() ? 'ring-2 ring-blue-500' : ''
                    }`}
                    onClick={() => handleTemplateSelect(template.id.toString())}
                  >
                    <CardContent className="p-3">
                      <Typography variant="subtitle2" className="font-semibold text-gray-800 mb-1">
                        {template.name}
                      </Typography>
                      <Typography variant="body2" className="text-gray-600 text-sm mb-2">
                        {template.title}
                      </Typography>
                      <Typography variant="body2" className="text-gray-500 text-xs line-clamp-2">
                        {template.body}
                      </Typography>
                      {template.variables.length > 0 && (
                        <Box className="mt-2 flex flex-wrap gap-1">
                          {template.variables.map((variable, index) => (
                            <Chip
                              key={index}
                              label={`{${variable}}`}
                              size="small"
                              variant="outlined"
                              className="text-xs"
                            />
                          ))}
                        </Box>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </Paper>
          </Grid>
        </Grid>

        {/* Recent Notifications */}
        <Paper className="p-6">
          <Typography variant="h6" className="font-semibold text-gray-800 mb-4">
            Recent Notifications
          </Typography>
          
          <div className="space-y-3">
            {[
              {
                title: 'Route Update Notification',
                body: 'Route from Johannesburg to Pretoria has been updated with new pricing.',
                type: 'push',
                target: 'All Users',
                sent: '2025-01-02 14:30',
                status: 'Delivered'
              },
              {
                title: 'Service Maintenance Alert',
                body: 'Scheduled maintenance will occur tonight from 2 AM to 4 AM.',
                type: 'email',
                target: 'All Users',
                sent: '2025-01-02 10:15',
                status: 'Delivered'
              },
              {
                title: 'Welcome Message',
                body: 'Welcome to GeoOut! Start exploring taxi routes in your area.',
                type: 'push',
                target: 'New Users',
                sent: '2025-01-02 09:45',
                status: 'Delivered'
              }
            ].map((notif, index) => (
              <Card key={index} className="border-l-4 border-blue-500">
                <CardContent className="p-4">
                  <Box className="flex items-start justify-between">
                    <div className="flex-1">
                      <Box className="flex items-center mb-2">
                        {getTypeIcon(notif.type)}
                        <Typography variant="subtitle1" className="font-semibold text-gray-800 ml-2">
                          {notif.title}
                        </Typography>
                      </Box>
                      <Typography variant="body2" className="text-gray-600 mb-2">
                        {notif.body}
                      </Typography>
                      <Box className="flex items-center gap-4 text-sm text-gray-500">
                        <span>Target: {notif.target}</span>
                        <span>•</span>
                        <span>Sent: {notif.sent}</span>
                      </Box>
                    </div>
                    <Chip
                      label={notif.status}
                      size="small"
                      color="success"
                      variant="outlined"
                    />
                  </Box>
                </CardContent>
              </Card>
            ))}
          </div>
        </Paper>
      </div>
    </Layout>
  );
};

export default Notifications;