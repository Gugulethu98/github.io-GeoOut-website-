import React, { useState } from 'react';
import {
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  Drawer,
  Box,
  Typography,
  Button,
  Divider
} from '@mui/material';
import {
  Visibility,
  Close
} from '@mui/icons-material';
import Layout from '../components/Layout/Layout';
import { tickets } from '../mockData';

const SupportTickets: React.FC = () => {
  const [selectedTicket, setSelectedTicket] = useState<any>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);

  const handleViewTicket = (ticket: any) => {
    setSelectedTicket(ticket);
    setDrawerOpen(true);
    console.log('View ticket:', ticket);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'OPEN': return { color: 'primary', bg: 'bg-blue-50' };
      case 'RESOLVED': return { color: 'success', bg: 'bg-green-50' };
      case 'CLOSED': return { color: 'default', bg: 'bg-gray-50' };
      default: return { color: 'default', bg: 'bg-gray-50' };
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'High': return 'error';
      case 'Medium': return 'warning';
      case 'Low': return 'info';
      default: return 'default';
    }
  };

  return (
    <Layout pageTitle="Support Tickets">
      <div className="space-y-4">
        {/* Tickets Table */}
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow className="bg-gray-50">
                <TableCell className="font-semibold">Ticket ID</TableCell>
                <TableCell className="font-semibold">Subject</TableCell>
                <TableCell className="font-semibold">Status</TableCell>
                <TableCell className="font-semibold">Priority</TableCell>
                <TableCell className="font-semibold">Assigned To</TableCell>
                <TableCell className="font-semibold">Created</TableCell>
                <TableCell className="font-semibold">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {tickets.map((ticket) => (
                <TableRow key={ticket.id} hover>
                  <TableCell className="font-medium">{ticket.id}</TableCell>
                  <TableCell className="max-w-xs truncate">{ticket.subject}</TableCell>
                  <TableCell>
                    <Chip
                      label={ticket.status}
                      color={getStatusColor(ticket.status).color as any}
                      size="small"
                      className={getStatusColor(ticket.status).bg}
                    />
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={ticket.priority}
                      color={getPriorityColor(ticket.priority) as any}
                      size="small"
                      variant="outlined"
                    />
                  </TableCell>
                  <TableCell>{ticket.assignedTo}</TableCell>
                  <TableCell className="text-gray-600">{ticket.createdAt}</TableCell>
                  <TableCell>
                    <IconButton
                      size="small"
                      onClick={() => handleViewTicket(ticket)}
                      className="text-blue-600 hover:bg-blue-50"
                    >
                      <Visibility fontSize="small" />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        {/* Ticket Details Drawer */}
        <Drawer
          anchor="right"
          open={drawerOpen}
          onClose={() => setDrawerOpen(false)}
          PaperProps={{
            sx: { width: { xs: '100%', sm: 400 } }
          }}
        >
          <Box className="p-4 h-full">
            <Box className="flex items-center justify-between mb-4">
              <Typography variant="h6" className="font-semibold">
                Ticket Details
              </Typography>
              <IconButton onClick={() => setDrawerOpen(false)}>
                <Close />
              </IconButton>
            </Box>

            {selectedTicket && (
              <div className="space-y-4">
                <Box>
                  <Typography variant="subtitle2" className="text-gray-600 mb-1">
                    Ticket ID
                  </Typography>
                  <Typography variant="body1" className="font-medium">
                    {selectedTicket.id}
                  </Typography>
                </Box>

                <Box>
                  <Typography variant="subtitle2" className="text-gray-600 mb-1">
                    Subject
                  </Typography>
                  <Typography variant="body1">
                    {selectedTicket.subject}
                  </Typography>
                </Box>

                <Box className="flex gap-4">
                  <Box className="flex-1">
                    <Typography variant="subtitle2" className="text-gray-600 mb-1">
                      Status
                    </Typography>
                    <Chip
                      label={selectedTicket.status}
                      color={getStatusColor(selectedTicket.status).color as any}
                      size="small"
                    />
                  </Box>
                  <Box className="flex-1">
                    <Typography variant="subtitle2" className="text-gray-600 mb-1">
                      Priority
                    </Typography>
                    <Chip
                      label={selectedTicket.priority}
                      color={getPriorityColor(selectedTicket.priority) as any}
                      size="small"
                      variant="outlined"
                    />
                  </Box>
                </Box>

                <Box>
                  <Typography variant="subtitle2" className="text-gray-600 mb-1">
                    Assigned To
                  </Typography>
                  <Typography variant="body1">
                    {selectedTicket.assignedTo}
                  </Typography>
                </Box>

                <Box>
                  <Typography variant="subtitle2" className="text-gray-600 mb-1">
                    Created By
                  </Typography>
                  <Typography variant="body1">
                    {selectedTicket.createdBy}
                  </Typography>
                </Box>

                <Box>
                  <Typography variant="subtitle2" className="text-gray-600 mb-1">
                    Created At
                  </Typography>
                  <Typography variant="body1">
                    {selectedTicket.createdAt}
                  </Typography>
                </Box>

                <Divider />

                <Box>
                  <Typography variant="subtitle2" className="text-gray-600 mb-2">
                    Description
                  </Typography>
                  <Typography variant="body2" className="text-gray-800 leading-relaxed">
                    {selectedTicket.description}
                  </Typography>
                </Box>

                <Box className="pt-4 space-y-2">
                  <Button
                    variant="contained"
                    fullWidth
                    className="bg-blue-600 hover:bg-blue-700"
                    onClick={() => console.log('Update ticket status')}
                  >
                    Update Status
                  </Button>
                  <Button
                    variant="outlined"
                    fullWidth
                    onClick={() => console.log('Assign ticket')}
                  >
                    Reassign Ticket
                  </Button>
                </Box>
              </div>
            )}
          </Box>
        </Drawer>
      </div>
    </Layout>
  );
};

export default SupportTickets;