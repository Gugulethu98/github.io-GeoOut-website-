import React from 'react';
import { Grid, Card, CardContent, Typography, Box, Paper } from '@mui/material';
import {
  People,
  LocalTaxi,
  SupportAgent,
  Route,
  TrendingUp,
  CheckCircle,
  Warning,
  Schedule
} from '@mui/icons-material';
import Layout from '../components/Layout/Layout';
import { dashboardStats } from '../mockData';

const Dashboard: React.FC = () => {
  const summaryCards = [
    {
      title: 'Total Users',
      value: dashboardStats.totalUsers.toLocaleString(),
      icon: <People className="text-blue-600 text-4xl" />,
      color: 'bg-blue-50',
      change: '+12%',
      changeColor: 'text-green-600'
    },
    {
      title: 'Active Taxi Ranks',
      value: dashboardStats.activeTaxiRanks.toString(),
      icon: <LocalTaxi className="text-green-600 text-4xl" />,
      color: 'bg-green-50',
      change: '+3%',
      changeColor: 'text-green-600'
    },
    {
      title: 'Open Tickets',
      value: dashboardStats.openTickets.toString(),
      icon: <SupportAgent className="text-orange-600 text-4xl" />,
      color: 'bg-orange-50',
      change: '-8%',
      changeColor: 'text-green-600'
    },
    {
      title: 'Pending Routes',
      value: dashboardStats.pendingRoutes.toString(),
      icon: <Route className="text-purple-600 text-4xl" />,
      color: 'bg-purple-50',
      change: '+2%',
      changeColor: 'text-green-600'
    }
  ];

  const getHealthStatusColor = (status: string) => {
    switch (status) {
      case 'Healthy': return 'text-green-600';
      case 'Warning': return 'text-yellow-600';
      case 'Critical': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getHealthStatusIcon = (status: string) => {
    switch (status) {
      case 'Healthy': return <CheckCircle className="text-green-600" />;
      case 'Warning': return <Warning className="text-yellow-600" />;
      case 'Critical': return <Warning className="text-red-600" />;
      default: return <Schedule className="text-gray-600" />;
    }
  };

  return (
    <Layout pageTitle="Dashboard">
      <div className="space-y-6">
        {/* Summary Cards */}
        <Grid container spacing={3}>
          {summaryCards.map((card, index) => (
            <Grid item xs={12} sm={6} md={3} key={index}>
              <Card className="h-full hover:shadow-lg transition-shadow">
                <CardContent>
                  <Box className="flex items-center justify-between">
                    <div>
                      <Typography variant="h4" className="font-bold text-gray-800 mb-1">
                        {card.value}
                      </Typography>
                      <Typography variant="body2" className="text-gray-600 mb-2">
                        {card.title}
                      </Typography>
                      <Box className="flex items-center">
                        <TrendingUp className="text-sm mr-1" />
                        <Typography variant="body2" className={card.changeColor}>
                          {card.change} from last month
                        </Typography>
                      </Box>
                    </div>
                    <Box className={`p-3 rounded-full ${card.color}`}>
                      {card.icon}
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>

        {/* System Health Section */}
        <Paper className="p-6">
          <Typography variant="h6" className="font-semibold text-gray-800 mb-4">
            System Health
          </Typography>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Card className="h-full">
                <CardContent>
                  <Box className="flex items-center justify-between mb-4">
                    <Typography variant="h6" className="text-gray-700">
                      Overall Status
                    </Typography>
                    {getHealthStatusIcon(dashboardStats.systemHealth.status)}
                  </Box>
                  <Typography 
                    variant="h4" 
                    className={`font-bold mb-2 ${getHealthStatusColor(dashboardStats.systemHealth.status)}`}
                  >
                    {dashboardStats.systemHealth.status}
                  </Typography>
                  <Typography variant="body2" className="text-gray-600">
                    System is operating normally
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Card className="h-full">
                <CardContent>
                  <Typography variant="h6" className="text-gray-700 mb-4">
                    System Metrics
                  </Typography>
                  <div className="space-y-3">
                    <Box className="flex justify-between">
                      <Typography variant="body2" className="text-gray-600">
                        Uptime
                      </Typography>
                      <Typography variant="body2" className="font-semibold text-green-600">
                        {dashboardStats.systemHealth.uptime}
                      </Typography>
                    </Box>
                    <Box className="flex justify-between">
                      <Typography variant="body2" className="text-gray-600">
                        Active Services
                      </Typography>
                      <Typography variant="body2" className="font-semibold">
                        {dashboardStats.systemHealth.activeServices}/{dashboardStats.systemHealth.totalServices}
                      </Typography>
                    </Box>
                    <Box className="flex justify-between">
                      <Typography variant="body2" className="text-gray-600">
                        Last Incident
                      </Typography>
                      <Typography variant="body2" className="font-semibold">
                        {dashboardStats.systemHealth.lastIncident}
                      </Typography>
                    </Box>
                  </div>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Paper>

        {/* Quick Actions */}
        <Paper className="p-6">
          <Typography variant="h6" className="font-semibold text-gray-800 mb-4">
            Quick Actions
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6} md={3}>
              <Card className="cursor-pointer hover:shadow-md transition-shadow bg-blue-50">
                <CardContent className="text-center">
                  <People className="text-blue-600 text-3xl mb-2" />
                  <Typography variant="body2" className="text-blue-800 font-medium">
                    View All Users
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Card className="cursor-pointer hover:shadow-md transition-shadow bg-green-50">
                <CardContent className="text-center">
                  <LocalTaxi className="text-green-600 text-3xl mb-2" />
                  <Typography variant="body2" className="text-green-800 font-medium">
                    Manage Taxi Ranks
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Card className="cursor-pointer hover:shadow-md transition-shadow bg-orange-50">
                <CardContent className="text-center">
                  <SupportAgent className="text-orange-600 text-3xl mb-2" />
                  <Typography variant="body2" className="text-orange-800 font-medium">
                    Support Tickets
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Card className="cursor-pointer hover:shadow-md transition-shadow bg-purple-50">
                <CardContent className="text-center">
                  <Route className="text-purple-600 text-3xl mb-2" />
                  <Typography variant="body2" className="text-purple-800 font-medium">
                    Route Management
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Paper>
      </div>
    </Layout>
  );
};

export default Dashboard;