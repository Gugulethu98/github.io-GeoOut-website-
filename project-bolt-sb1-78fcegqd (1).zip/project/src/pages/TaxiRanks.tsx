import React, { useState } from 'react';
import {
  Paper,
  Card,
  CardContent,
  Typography,
  Button,
  Grid,
  Box,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField
} from '@mui/material';
import {
  LocationOn,
  AccessTime,
  LocalAtm,
  Add
} from '@mui/icons-material';
import Layout from '../components/Layout/Layout';
import { taxiRanks } from '../mockData';

const TaxiRanks: React.FC = () => {
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [newRank, setNewRank] = useState({
    name: '',
    location: '',
    pricing: '',
    capacity: '',
    operatingHours: ''
  });

  const handleAddRank = () => {
    console.log('Add new taxi rank:', newRank);
    setAddDialogOpen(false);
    setNewRank({
      name: '',
      location: '',
      pricing: '',
      capacity: '',
      operatingHours: ''
    });
  };

  return (
    <Layout pageTitle="Taxi Ranks Management">
      <div className="space-y-6">
        {/* Header with Add Button */}
        <Box className="flex justify-between items-center">
          <Typography variant="h5" className="font-semibold text-gray-800">
            Taxi Ranks Overview
          </Typography>
          <Button
            variant="contained"
            startIcon={<Add />}
            onClick={() => setAddDialogOpen(true)}
            className="bg-blue-600 hover:bg-blue-700"
          >
            Add Taxi Rank
          </Button>
        </Box>

        {/* Map Placeholder */}
        <Paper className="p-4">
          <Typography variant="h6" className="mb-4 font-semibold text-gray-800">
            Taxi Ranks Map
          </Typography>
          <Box className="w-full h-96 bg-gray-100 rounded-lg flex items-center justify-center">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3580.7729!2d28.0473!3d-26.2041!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjbCsDEyJzE0LjgiUyAyOMKwMDInNTAuMyJF!5e0!3m2!1sen!2sza!4v1234567890"
              width="100%"
              height="100%"
              style={{ border: 0, borderRadius: '8px' }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Taxi Ranks Map"
            />
          </Box>
        </Paper>

        {/* Taxi Ranks Grid */}
        <Grid container spacing={3}>
          {taxiRanks.map((rank) => (
            <Grid item xs={12} md={6} lg={4} key={rank.id}>
              <Card className="h-full hover:shadow-lg transition-shadow">
                <CardContent>
                  <Typography variant="h6" className="font-semibold text-gray-800 mb-2">
                    {rank.name}
                  </Typography>
                  
                  <Box className="flex items-start mb-3">
                    <LocationOn className="text-gray-500 mr-2 mt-1" fontSize="small" />
                    <Typography variant="body2" className="text-gray-600 flex-1">
                      {rank.location}
                    </Typography>
                  </Box>

                  <Box className="flex items-center mb-3">
                    <LocalAtm className="text-gray-500 mr-2" fontSize="small" />
                    <Typography variant="body2" className="text-gray-600">
                      {rank.pricing}
                    </Typography>
                  </Box>

                  <Box className="flex items-center mb-3">
                    <AccessTime className="text-gray-500 mr-2" fontSize="small" />
                    <Typography variant="body2" className="text-gray-600">
                      {rank.operatingHours}
                    </Typography>
                  </Box>

                  <Box className="mb-3">
                    <Typography variant="body2" className="text-gray-600 mb-2">
                      Capacity: {rank.capacity} vehicles
                    </Typography>
                  </Box>

                  <Box className="mb-4">
                    <Typography variant="body2" className="text-gray-600 mb-2">
                      Facilities:
                    </Typography>
                    <Box className="flex flex-wrap gap-1">
                      {rank.facilities.map((facility, index) => (
                        <Chip
                          key={index}
                          label={facility}
                          size="small"
                          variant="outlined"
                          className="text-xs"
                        />
                      ))}
                    </Box>
                  </Box>

                  <Box className="flex gap-2">
                    <Button
                      size="small"
                      variant="outlined"
                      onClick={() => console.log('Edit rank:', rank)}
                      className="flex-1"
                    >
                      Edit
                    </Button>
                    <Button
                      size="small"
                      variant="contained"
                      onClick={() => console.log('View details:', rank)}
                      className="flex-1 bg-blue-600 hover:bg-blue-700"
                    >
                      View Details
                    </Button>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>

        {/* Add Taxi Rank Dialog */}
        <Dialog open={addDialogOpen} onClose={() => setAddDialogOpen(false)} maxWidth="sm" fullWidth>
          <DialogTitle>Add New Taxi Rank</DialogTitle>
          <DialogContent>
            <div className="space-y-4 pt-2">
              <TextField
                fullWidth
                label="Rank Name"
                value={newRank.name}
                onChange={(e) => setNewRank({ ...newRank, name: e.target.value })}
              />
              <TextField
                fullWidth
                label="Location"
                value={newRank.location}
                onChange={(e) => setNewRank({ ...newRank, location: e.target.value })}
              />
              <TextField
                fullWidth
                label="Pricing Range"
                placeholder="e.g., R10 - R30 per trip"
                value={newRank.pricing}
                onChange={(e) => setNewRank({ ...newRank, pricing: e.target.value })}
              />
              <TextField
                fullWidth
                label="Capacity"
                type="number"
                value={newRank.capacity}
                onChange={(e) => setNewRank({ ...newRank, capacity: e.target.value })}
              />
              <TextField
                fullWidth
                label="Operating Hours"
                placeholder="e.g., 05:00 - 22:00"
                value={newRank.operatingHours}
                onChange={(e) => setNewRank({ ...newRank, operatingHours: e.target.value })}
              />
            </div>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setAddDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleAddRank} variant="contained" className="bg-blue-600 hover:bg-blue-700">
              Add Rank
            </Button>
          </DialogActions>
        </Dialog>
      </div>
    </Layout>
  );
};

export default TaxiRanks;