import React, { useState } from 'react';
import {
  Paper,
  TextField,
  Button,
  Typography,
  Box,
  Grid,
  Divider,
  Card,
  CardContent,
  Avatar
} from '@mui/material';
import {
  Save,
  Person,
  Email,
  Settings as SettingsIcon
} from '@mui/icons-material';
import Layout from '../components/Layout/Layout';

const Settings: React.FC = () => {
  const [emailSettings, setEmailSettings] = useState({
    smtpHost: 'smtp.gmail.com',
    smtpPort: '587',
    fromEmail: 'admin@geoout.com',
    fromName: 'GeoOut Admin'
  });

  const [adminProfile, setAdminProfile] = useState({
    name: 'Admin User',
    email: 'admin@geoout.com',
    phone: '+27 82 123 4567',
    role: 'Super Administrator'
  });

  const handleSaveEmailSettings = () => {
    console.log('Save email settings:', emailSettings);
  };

  const handleSaveProfile = () => {
    console.log('Save admin profile:', adminProfile);
  };

  return (
    <Layout pageTitle="Settings">
      <div className="space-y-6">
        <Grid container spacing={4}>
          {/* Admin Profile */}
          <Grid item xs={12} md={6}>
            <Paper className="p-6">
              <Typography variant="h6" className="font-semibold text-gray-800 mb-4 flex items-center">
                <Person className="mr-2" />
                Admin Profile
              </Typography>
              
              <Box className="flex items-center mb-6">
                <Avatar className="bg-blue-600 w-16 h-16 text-xl mr-4">
                  A
                </Avatar>
                <div>
                  <Typography variant="h6" className="font-semibold">
                    {adminProfile.name}
                  </Typography>
                  <Typography variant="body2" className="text-gray-600">
                    {adminProfile.role}
                  </Typography>
                </div>
              </Box>

              <div className="space-y-4">
                <TextField
                  fullWidth
                  label="Full Name"
                  value={adminProfile.name}
                  onChange={(e) => setAdminProfile({ ...adminProfile, name: e.target.value })}
                />
                
                <TextField
                  fullWidth
                  label="Email Address"
                  type="email"
                  value={adminProfile.email}
                  onChange={(e) => setAdminProfile({ ...adminProfile, email: e.target.value })}
                />

                <TextField
                  fullWidth
                  label="Phone Number"
                  value={adminProfile.phone}
                  onChange={(e) => setAdminProfile({ ...adminProfile, phone: e.target.value })}
                />

                <TextField
                  fullWidth
                  label="Role"
                  value={adminProfile.role}
                  onChange={(e) => setAdminProfile({ ...adminProfile, role: e.target.value })}
                  disabled
                />

                <Button
                  variant="contained"
                  startIcon={<Save />}
                  onClick={handleSaveProfile}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Save Profile
                </Button>
              </div>
            </Paper>
          </Grid>

          {/* Email Settings */}
          <Grid item xs={12} md={6}>
            <Paper className="p-6">
              <Typography variant="h6" className="font-semibold text-gray-800 mb-4 flex items-center">
                <Email className="mr-2" />
                Email Settings
              </Typography>
              
              <div className="space-y-4">
                <TextField
                  fullWidth
                  label="SMTP Host"
                  value={emailSettings.smtpHost}
                  onChange={(e) => setEmailSettings({ ...emailSettings, smtpHost: e.target.value })}
                />
                
                <TextField
                  fullWidth
                  label="SMTP Port"
                  type="number"
                  value={emailSettings.smtpPort}
                  onChange={(e) => setEmailSettings({ ...emailSettings, smtpPort: e.target.value })}
                />

                <TextField
                  fullWidth
                  label="From Email"
                  type="email"
                  value={emailSettings.fromEmail}
                  onChange={(e) => setEmailSettings({ ...emailSettings, fromEmail: e.target.value })}
                />

                <TextField
                  fullWidth
                  label="From Name"
                  value={emailSettings.fromName}
                  onChange={(e) => setEmailSettings({ ...emailSettings, fromName: e.target.value })}
                />

                <Button
                  variant="contained"
                  startIcon={<Save />}
                  onClick={handleSaveEmailSettings}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Save Email Settings
                </Button>
              </div>
            </Paper>
          </Grid>
        </Grid>

        {/* System Configuration */}
        <Paper className="p-6">
          <Typography variant="h6" className="font-semibold text-gray-800 mb-4 flex items-center">
            <SettingsIcon className="mr-2" />
            System Configuration
          </Typography>
          
          <Grid container spacing={4}>
            <Grid item xs={12} md={6}>
              <Card className="bg-gray-50">
                <CardContent>
                  <Typography variant="subtitle1" className="font-semibold mb-2">
                    Application Settings
                  </Typography>
                  <div className="space-y-3">
                    <Box className="flex justify-between items-center">
                      <Typography variant="body2" className="text-gray-600">
                        App Version
                      </Typography>
                      <Typography variant="body2" className="font-medium">
                        v1.0.0
                      </Typography>
                    </Box>
                    <Box className="flex justify-between items-center">
                      <Typography variant="body2" className="text-gray-600">
                        Environment
                      </Typography>
                      <Typography variant="body2" className="font-medium">
                        Production
                      </Typography>
                    </Box>
                    <Box className="flex justify-between items-center">
                      <Typography variant="body2" className="text-gray-600">
                        Database Status
                      </Typography>
                      <Typography variant="body2" className="font-medium text-green-600">
                        Connected
                      </Typography>
                    </Box>
                  </div>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} md={6}>
              <Card className="bg-gray-50">
                <CardContent>
                  <Typography variant="subtitle1" className="font-semibold mb-2">
                    Security Settings
                  </Typography>
                  <div className="space-y-3">
                    <Box className="flex justify-between items-center">
                      <Typography variant="body2" className="text-gray-600">
                        Session Timeout
                      </Typography>
                      <Typography variant="body2" className="font-medium">
                        30 minutes
                      </Typography>
                    </Box>
                    <Box className="flex justify-between items-center">
                      <Typography variant="body2" className="text-gray-600">
                        Password Policy
                      </Typography>
                      <Typography variant="body2" className="font-medium">
                        Strong
                      </Typography>
                    </Box>
                    <Box className="flex justify-between items-center">
                      <Typography variant="body2" className="text-gray-600">
                        Login Attempts
                      </Typography>
                      <Typography variant="body2" className="font-medium">
                        5 max
                      </Typography>
                    </Box>
                  </div>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Paper>
      </div>
    </Layout>
  );
};

export default Settings;