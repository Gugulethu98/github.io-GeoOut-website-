import React, { useState } from 'react';
import {
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Button,
  Chip,
  IconButton,
  Box,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Typography
} from '@mui/material';
import {
  Visibility,
  Block,
  Delete,
  Search
} from '@mui/icons-material';
import Layout from '../components/Layout/Layout';
import { users } from '../mockData';

const Users: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || user.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleView = (user: any) => {
    setSelectedUser(user);
    setViewDialogOpen(true);
    console.log('View user:', user);
  };

  const handleSuspend = (user: any) => {
    console.log('Suspend user:', user);
    // Mock suspend action
  };

  const handleDelete = (user: any) => {
    console.log('Delete user:', user);
    // Mock delete action
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active': return 'success';
      case 'Suspended': return 'error';
      default: return 'default';
    }
  };

  return (
    <Layout pageTitle="Users Management">
      <div className="space-y-4">
        {/* Search and Filter Controls */}
        <Paper className="p-4">
          <Box className="flex flex-col sm:flex-row gap-4 items-center">
            <TextField
              placeholder="Search users..."
              variant="outlined"
              size="small"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              InputProps={{
                startAdornment: <Search className="text-gray-400 mr-2" />
              }}
              className="flex-1"
            />
            <FormControl size="small" className="min-w-32">
              <InputLabel>Status</InputLabel>
              <Select
                value={statusFilter}
                label="Status"
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                <MenuItem value="All">All</MenuItem>
                <MenuItem value="Active">Active</MenuItem>
                <MenuItem value="Suspended">Suspended</MenuItem>
              </Select>
            </FormControl>
          </Box>
        </Paper>

        {/* Users Table */}
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow className="bg-gray-50">
                <TableCell className="font-semibold">Name</TableCell>
                <TableCell className="font-semibold">Email</TableCell>
                <TableCell className="font-semibold">Phone</TableCell>
                <TableCell className="font-semibold">Status</TableCell>
                <TableCell className="font-semibold">Last Seen</TableCell>
                <TableCell className="font-semibold">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredUsers.map((user) => (
                <TableRow key={user.id} hover>
                  <TableCell className="font-medium">{user.name}</TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>{user.phone}</TableCell>
                  <TableCell>
                    <Chip
                      label={user.status}
                      color={getStatusColor(user.status) as any}
                      size="small"
                    />
                  </TableCell>
                  <TableCell className="text-gray-600">{user.lastSeen}</TableCell>
                  <TableCell>
                    <Box className="flex gap-1">
                      <IconButton
                        size="small"
                        onClick={() => handleView(user)}
                        className="text-blue-600 hover:bg-blue-50"
                      >
                        <Visibility fontSize="small" />
                      </IconButton>
                      <IconButton
                        size="small"
                        onClick={() => handleSuspend(user)}
                        className="text-orange-600 hover:bg-orange-50"
                      >
                        <Block fontSize="small" />
                      </IconButton>
                      <IconButton
                        size="small"
                        onClick={() => handleDelete(user)}
                        className="text-red-600 hover:bg-red-50"
                      >
                        <Delete fontSize="small" />
                      </IconButton>
                    </Box>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        {/* User Details Dialog */}
        <Dialog open={viewDialogOpen} onClose={() => setViewDialogOpen(false)} maxWidth="sm" fullWidth>
          <DialogTitle>User Details</DialogTitle>
          <DialogContent>
            {selectedUser && (
              <div className="space-y-4 pt-2">
                <Box>
                  <Typography variant="subtitle2" className="text-gray-600">Name</Typography>
                  <Typography variant="body1">{selectedUser.name}</Typography>
                </Box>
                <Box>
                  <Typography variant="subtitle2" className="text-gray-600">Email</Typography>
                  <Typography variant="body1">{selectedUser.email}</Typography>
                </Box>
                <Box>
                  <Typography variant="subtitle2" className="text-gray-600">Phone</Typography>
                  <Typography variant="body1">{selectedUser.phone}</Typography>
                </Box>
                <Box>
                  <Typography variant="subtitle2" className="text-gray-600">Status</Typography>
                  <Chip
                    label={selectedUser.status}
                    color={getStatusColor(selectedUser.status) as any}
                    size="small"
                  />
                </Box>
                <Box>
                  <Typography variant="subtitle2" className="text-gray-600">Join Date</Typography>
                  <Typography variant="body1">{selectedUser.joinDate}</Typography>
                </Box>
                <Box>
                  <Typography variant="subtitle2" className="text-gray-600">Total Trips</Typography>
                  <Typography variant="body1">{selectedUser.totalTrips}</Typography>
                </Box>
                <Box>
                  <Typography variant="subtitle2" className="text-gray-600">Last Seen</Typography>
                  <Typography variant="body1">{selectedUser.lastSeen}</Typography>
                </Box>
              </div>
            )}
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setViewDialogOpen(false)}>Close</Button>
          </DialogActions>
        </Dialog>
      </div>
    </Layout>
  );
};

export default Users;