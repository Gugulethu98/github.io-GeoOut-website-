import { useState, useEffect } from 'react';

interface ScrollState {
  scrollY: number;
  backgroundOpacity: number;
  isTopNavHidden: boolean;
  isBackToTopVisible: boolean;
}

export const useScrollEffects = () => {
  const [scrollState, setScrollState] = useState<ScrollState>({
    scrollY: 0,
    backgroundOpacity: 0,
    isTopNavHidden: false,
    isBackToTopVisible: false,
  });

  useEffect(() => {
    let lastScrollTop = 0;

    const handleScroll = () => {
      const currentScrollY = window.pageYOffset || document.documentElement.scrollTop;
      
      // Background image opacity logic - matches HTML exactly
      const backgroundOpacity = currentScrollY > lastScrollTop ? 0.3 : 0;
      
      // Top nav hide/show logic - matches HTML exactly
      let isTopNavHidden = false;
      if (currentScrollY < 100) {
        isTopNavHidden = false;
      } else if (currentScrollY > lastScrollTop) {
        // Scrolling down → hide
        isTopNavHidden = true;
      } else {
        // Scrolling up → show
        isTopNavHidden = false;
      }
      
      // Back to top button visibility
      const isBackToTopVisible = currentScrollY > 200;

      setScrollState({
        scrollY: currentScrollY,
        backgroundOpacity,
        isTopNavHidden,
        isBackToTopVisible,
      });

      lastScrollTop = currentScrollY <= 0 ? 0 : currentScrollY;
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return scrollState;
};