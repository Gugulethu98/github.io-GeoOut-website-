import React from 'react';
import { Pin } from 'lucide-react';

interface SideMenuButtonProps {
  onClick: () => void;
}

const SideMenuButton: React.FC<SideMenuButtonProps> = ({ onClick }) => {
  return (
    <button
      onClick={onClick}
      className="fixed top-5 left-5 bg-gray-800 text-white p-3 rounded-full cursor-pointer z-30 hover:bg-gray-700 transition-colors max-sm:top-4 max-sm:left-4 max-sm:p-2"
    >
      <Pin className="w-5 h-5" />
    </button>
  );
};

export default SideMenuButton;