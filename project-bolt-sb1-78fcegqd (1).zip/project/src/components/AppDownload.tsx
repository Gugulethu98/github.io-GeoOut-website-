import React from 'react';

const AppDownload: React.FC = () => {
  return (
    <div className="text-center my-5">
      <a 
        href="https://play.google.com/store/apps/details?id=your.app.id" 
        target="_blank" 
        rel="noopener noreferrer"
        className="inline-block mx-2.5 my-2.5"
      >
        <img 
          src="https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg"
          alt="Get it on Google Play" 
          className="h-12 hover:scale-105 transition-transform"
        />
      </a>
      <a 
        href="https://apps.apple.com/app/idYourAppID" 
        target="_blank" 
        rel="noopener noreferrer"
        className="inline-block mx-2.5 my-2.5"
      >
        <img 
          src="https://developer.apple.com/assets/elements/badges/download-on-the-app-store.svg"
          alt="Download on the App Store" 
          className="h-12 hover:scale-105 transition-transform"
        />
      </a>
    </div>
  );
};

export default AppDownload;