import React from 'react';

const About: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto my-12 px-5 text-center">
      <h2 className="text-3xl font-bold text-gray-300 mb-4">
        About GeoOut
      </h2>
      <p className="text-base text-gray-400 leading-relaxed mb-8">
        GeoOut is a mobile platform built to guide users to local taxi ranks, real-time pricing,
        and accurate route directions. It's designed to support commuters, empower drivers,
        and make travel smarter and more efficient in South Africa and beyond.
      </p>
      <h6 className="text-sm font-bold text-gray-300">
        <b>Your digital travel companion for real-time taxi routes, pricing and directions</b>
      </h6>
    </div>
  );
};

export default About;