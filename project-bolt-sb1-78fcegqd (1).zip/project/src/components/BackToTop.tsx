import React from 'react';
import { ArrowUp } from 'lucide-react';

interface BackToTopProps {
  isVisible: boolean;
  onClick: () => void;
}

const BackToTop: React.FC<BackToTopProps> = ({ isVisible, onClick }) => {
  return (
    <button
      onClick={onClick}
      className={`fixed bottom-10 right-8 z-50 text-2xl bg-black bg-opacity-70 text-white border-none rounded-full p-4 cursor-pointer shadow-lg transition-all duration-400 hover:bg-blue-600 ${
        isVisible ? 'opacity-100 pointer-events-auto block' : 'opacity-0 pointer-events-none hidden'
      }`}
      title="Back to Top"
    >
      <ArrowUp className="w-6 h-6" />
    </button>
  );
};

export default BackToTop;