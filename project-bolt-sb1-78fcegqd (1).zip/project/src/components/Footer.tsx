import React from 'react';
import { Facebook, Twitter, Instagram } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="relative z-10">
      <div className="bg-gray-900 py-10 px-5 border-t border-gray-800">
        <div className="flex justify-around flex-wrap text-white max-md:flex-col max-md:items-center max-md:text-center">
          <div className="flex-1 mx-2.5 min-w-[150px] mb-5 max-md:mb-5">
            <strong className="block mb-2.5 text-lg text-white">Discover</strong>
            <ul className="list-none p-0">
              <li className="mb-2">
                <a href="#" className="text-gray-400 no-underline text-sm hover:text-white transition-colors">
                  Why GeoOut?
                </a>
              </li>
              <li className="mb-2">
                <a href="#" className="text-gray-400 no-underline text-sm hover:text-white transition-colors">
                  How it Works
                </a>
              </li>
              <li className="mb-2">
                <a href="#" className="text-gray-400 no-underline text-sm hover:text-white transition-colors">
                  Safety
                </a>
              </li>
              <li className="mb-2">
                <a href="#" className="text-gray-400 no-underline text-sm hover:text-white transition-colors">
                  Partners
                </a>
              </li>
            </ul>
          </div>

          <div className="flex-1 mx-2.5 min-w-[150px] mb-5 max-md:mb-5">
            <strong className="block mb-2.5 text-lg text-white">Company</strong>
            <ul className="list-none p-0">
              <li className="mb-2">
                <a href="#" className="text-gray-400 no-underline text-sm hover:text-white transition-colors">
                  About
                </a>
              </li>
              <li className="mb-2">
                <a href="#" className="text-gray-400 no-underline text-sm hover:text-white transition-colors">
                  Careers
                </a>
              </li>
              <li className="mb-2">
                <a href="#" className="text-gray-400 no-underline text-sm hover:text-white transition-colors">
                  Newsroom
                </a>
              </li>
            </ul>
          </div>

          <div className="flex-1 mx-2.5 min-w-[150px] mb-5 max-md:mb-5">
            <strong className="block mb-2.5 text-lg text-white">Contact</strong>
            <ul className="list-none p-0">
              <li className="mb-2">
                <a href="#" className="text-gray-400 no-underline text-sm hover:text-white transition-colors">
                  Support
                </a>
              </li>
              <li className="mb-2">
                <a href="#" className="text-gray-400 no-underline text-sm hover:text-white transition-colors">
                  Media
                </a>
              </li>
              <li className="mb-2">
                <a href="#" className="text-gray-400 no-underline text-sm hover:text-white transition-colors">
                  Developers
                </a>
              </li>
            </ul>
          </div>

          <div className="flex-1 mx-2.5 min-w-[150px] mb-5 max-md:mb-5">
            <strong className="block mb-2.5 text-lg text-white">Follow Us</strong>
            <div className="flex gap-4 max-md:justify-center">
              <a href="#" className="text-white hover:text-gray-300 transition-colors text-xl">
                <Facebook className="w-6 h-6" />
              </a>
              <a href="#" className="text-white hover:text-gray-300 transition-colors text-xl">
                <Twitter className="w-6 h-6" />
              </a>
              <a href="#" className="text-white hover:text-gray-300 transition-colors text-xl">
                <Instagram className="w-6 h-6" />
              </a>
            </div>
          </div>
        </div>
      </div>

      <div className="text-center text-gray-500 py-8 text-sm bg-black bg-opacity-50">
        <p className="mb-2">&copy; 2025 GeoOut. All rights reserved.</p>
        <p>
          <a href="#" className="text-blue-500 no-underline hover:underline">
            Terms of Service
          </a>
          {' | '}
          <a href="#" className="text-blue-500 no-underline hover:underline">
            Privacy Policy
          </a>
        </p>
      </div>
    </footer>
  );
};

export default Footer;