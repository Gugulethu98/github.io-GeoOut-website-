import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Box,
  Typography
} from '@mui/material';
import {
  Dashboard,
  People,
  SupportAgent,
  LocalTaxi,
  Route,
  Notifications,
  Settings
} from '@mui/icons-material';

const drawerWidth = 240;

const menuItems = [
  { text: 'Dashboard', icon: <Dashboard />, path: '/' },
  { text: 'Users', icon: <People />, path: '/users' },
  { text: 'Support Tickets', icon: <SupportAgent />, path: '/tickets' },
  { text: 'Taxi Ranks', icon: <LocalTaxi />, path: '/taxi-ranks' },
  { text: 'Routes', icon: <Route />, path: '/routes' },
  { text: 'Notifications', icon: <Notifications />, path: '/notifications' },
  { text: 'Settings', icon: <Settings />, path: '/settings' }
];

interface SidebarProps {
  mobileOpen: boolean;
  handleDrawerToggle: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ mobileOpen, handleDrawerToggle }) => {
  const navigate = useNavigate();
  const location = useLocation();

  const drawer = (
    <div>
      <Toolbar className="bg-blue-600">
        <Box className="flex items-center">
          <LocalTaxi className="text-white mr-2" />
          <Typography variant="h6" className="text-white font-bold">
            GeoOut Admin
          </Typography>
        </Box>
      </Toolbar>
      <List className="pt-0">
        {menuItems.map((item) => (
          <ListItem key={item.text} disablePadding>
            <ListItemButton
              onClick={() => navigate(item.path)}
              className={`${
                location.pathname === item.path
                  ? 'bg-blue-50 border-r-4 border-blue-600'
                  : 'hover:bg-gray-50'
              }`}
            >
              <ListItemIcon className={location.pathname === item.path ? 'text-blue-600' : 'text-gray-600'}>
                {item.icon}
              </ListItemIcon>
              <ListItemText 
                primary={item.text} 
                className={location.pathname === item.path ? 'text-blue-600' : 'text-gray-700'}
              />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </div>
  );

  return (
    <Box
      component="nav"
      sx={{ width: { sm: drawerWidth }, flexShrink: { sm: 0 } }}
    >
      <Drawer
        variant="temporary"
        open={mobileOpen}
        onClose={handleDrawerToggle}
        ModalProps={{
          keepMounted: true,
        }}
        sx={{
          display: { xs: 'block', sm: 'none' },
          '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth },
        }}
      >
        {drawer}
      </Drawer>
      <Drawer
        variant="permanent"
        sx={{
          display: { xs: 'none', sm: 'block' },
          '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth },
        }}
        open
      >
        {drawer}
      </Drawer>
    </Box>
  );
};

export default Sidebar;