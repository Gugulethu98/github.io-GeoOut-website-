import React, { useState } from 'react';
import {
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Menu,
  MenuItem,
  Avatar,
  Box
} from '@mui/material';
import {
  Menu as MenuIcon,
  AccountCircle,
  Logout
} from '@mui/icons-material';

interface NavbarProps {
  handleDrawerToggle: () => void;
  pageTitle: string;
}

const Navbar: React.FC<NavbarProps> = ({ handleDrawerToggle, pageTitle }) => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

  const handleMenu = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleProfile = () => {
    console.log('Navigate to profile');
    handleClose();
  };

  const handleLogout = () => {
    console.log('Logout user');
    handleClose();
  };

  return (
    <AppBar
      position="fixed"
      sx={{
        width: { sm: `calc(100% - 240px)` },
        ml: { sm: `240px` },
      }}
      className="bg-white shadow-sm"
    >
      <Toolbar className="bg-white">
        <IconButton
          color="inherit"
          aria-label="open drawer"
          edge="start"
          onClick={handleDrawerToggle}
          sx={{ mr: 2, display: { sm: 'none' } }}
          className="text-gray-700"
        >
          <MenuIcon />
        </IconButton>
        
        <Typography variant="h6" noWrap component="div" className="flex-grow text-gray-800 font-semibold">
          {pageTitle}
        </Typography>

        <Box className="flex items-center">
          <IconButton
            size="large"
            aria-label="account of current user"
            aria-controls="menu-appbar"
            aria-haspopup="true"
            onClick={handleMenu}
            color="inherit"
            className="text-gray-700"
          >
            <Avatar className="bg-blue-600 w-8 h-8">
              A
            </Avatar>
          </IconButton>
          <Menu
            id="menu-appbar"
            anchorEl={anchorEl}
            anchorOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
            keepMounted
            transformOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
            open={Boolean(anchorEl)}
            onClose={handleClose}
          >
            <MenuItem onClick={handleProfile} className="flex items-center">
              <AccountCircle className="mr-2" />
              Admin Profile
            </MenuItem>
            <MenuItem onClick={handleLogout} className="flex items-center">
              <Logout className="mr-2" />
              Logout
            </MenuItem>
          </Menu>
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;