import React from 'react';

interface HeroProps {
  backgroundOpacity: number;
}

const Hero: React.FC<HeroProps> = ({ backgroundOpacity }) => {
  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center text-white">
      {/* Background Image */}
      <div 
        className="fixed inset-0 bg-cover bg-center bg-no-repeat pointer-events-none z-0 transition-opacity duration-1000"
        style={{ 
          backgroundImage: 'url(https://images.pexels.com/photos/2519374/pexels-photo-2519374.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1)',
          opacity: backgroundOpacity 
        }}
      />
      
      <div className="relative z-10 text-center">
        <h1 className="text-9xl font-bold mb-4 mt-36 max-md:text-6xl max-sm:text-5xl">
          <b>GeoOut</b>
        </h1>
        <p className="text-xl text-gray-300 mt-2.5">
          Your digital travel companion
        </p>
      </div>
    </div>
  );
};

export default Hero;