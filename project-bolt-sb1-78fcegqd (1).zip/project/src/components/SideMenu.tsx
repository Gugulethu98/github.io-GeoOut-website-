import React from 'react';

interface SideMenuProps {
  isOpen: boolean;
}

const SideMenu: React.FC<SideMenuProps> = ({ isOpen }) => {
  return (
    <div className={`fixed top-0 h-full bg-gray-700 bg-opacity-80 text-white pt-16 transition-all duration-300 z-20 ${
      isOpen ? 'left-0 w-64' : '-left-64 w-64'
    } max-sm:${isOpen ? 'left-0 w-44' : '-left-44 w-44'}`}>
      <nav>
        <a href="#" className="block px-4 py-3 text-lg text-white no-underline hover:bg-gray-600 transition-colors">
          Home
        </a>
        <a href="#" className="block px-4 py-3 text-lg text-white no-underline hover:bg-gray-600 transition-colors">
          About
        </a>
        <a href="#" className="block px-4 py-3 text-lg text-white no-underline hover:bg-gray-600 transition-colors">
          Services
        </a>
        <a href="#" className="block px-4 py-3 text-lg text-white no-underline hover:bg-gray-600 transition-colors">
          Contact
        </a>
      </nav>
    </div>
  );
};

export default SideMenu;